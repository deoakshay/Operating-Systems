#define UTS_RELEASE "3.19.0-26-generic"
#define UTS_UBUNTU_RELEASE_ABI 26
